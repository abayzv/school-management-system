import React from 'react';
import axios from "axios";
import BootstrapTable from "react-bootstrap-table-next";
import 'react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css';
import paginationFactory from 'react-bootstrap-table2-paginator';
import Swal from 'sweetalert2'
import API from "../../services";
import { Modal, Button } from 'react-bootstrap';
import ToolkitProvider, { Search } from 'react-bootstrap-table2-toolkit';
import ReactTooltip from 'react-tooltip';


const swalWithBootstrapButtons = Swal.mixin({
    customClass: {
        confirmButton: 'btn btn-success mx-2',
        cancelButton: 'btn btn-danger'
    },
    buttonsStyling: false
})

// Fungsi Untuk Memanggil Tombol Search Pada Datatable
const { SearchBar } = Search;

class InvoiceComponent extends React.Component {
    // Constructor untuk Statefull Component
    constructor() {
        super();
        this.state = {
            visible: false,
            column: [
                {
                    dataField: 'nis',
                    text: 'Nis'
                },
                {
                    dataField: 'name',
                    text: 'Name',
                    sort: true
                },
                {
                    dataField: 'gender',
                    text: 'Gender',
                    formatter: function (cell, row) {
                        if (row.gender === "Laki - Laki") {
                            return <span class="badge rounded-pill text-success bg-light-success p-2 text-uppercase px-3"><i class="bx bxs-circle me-1"></i>{row.gender}</span>
                        } else {
                            return <span class="badge rounded-pill text-danger bg-light-danger p-2 text-uppercase px-3"><i class="bx bxs-circle me-1"></i>{row.gender}</span>
                        }
                    }
                },
                {
                    dataField: 'birth_place',
                    text: 'Birth Place'
                },
                {
                    dataField: 'birth_date',
                    text: 'Birth Date'
                },
                {
                    dataField: 'id',
                    text: 'Action',
                    formatter: this.action,
                },
            ],
            data: [],
            formStudent: {
                image: "https://i.pravatar.cc/300",
                password: "$2a$12$H1f6qPMXPMC02Gc9cKEb3OPZCQAjusg64Rjwxteq7vjzsbUMxyMs6",
                nis: "",
                name: "",
                gender: "",
                birth_place: "",
                birth_date: "",
                religion: "",
                address: "",
            },
            isUpdate: false
        }
    }

    // Funsi untuk membuka Modal
    openModal = () => {
        this.setState({
            visible: true
        });
    }

    // Fungsi untuk menutup Modal

    closeModal = () => {
        this.setState({
            visible: false
        });
    }

    // Fungsi untuk reset Form dan memanggil Modal
    resetInput = () => {
        this.setState({
            isUpdate: false,
            formStudent: {
                image: "https://i.pravatar.cc/300",
                password: "$2a$12$H1f6qPMXPMC02Gc9cKEb3OPZCQAjusg64Rjwxteq7vjzsbUMxyMs6",
                nis: "",
                name: "",
                gender: "",
                birth_place: "",
                birth_date: "",
                religion: "",
                address: "",
            }
        })
        this.openModal()
    }

    // Fungsi untuk update form
    handleFormChange = (event) => {
        const formStudentNew = { ...this.state.formStudent }
        formStudentNew[event.target.id] = event.target.value
        this.setState({
            formStudent: formStudentNew
        })
    }

    // Fungsi untuk Update & Save data melalui API
    saveHandler = () => {
        if (this.state.isUpdate) {
            API.updateStudent(this.state.formStudent.id, this.state.formStudent).then(res => {
                this.getStudentApi()
                this.resetInput()
                swalWithBootstrapButtons.fire(
                    'Success!',
                    'Student has been edited',
                    'success'
                )
            })
        } else {
            API.saveStudent(this.state.formStudent).then(res => {
                this.getStudentApi()
                this.resetInput()
                swalWithBootstrapButtons.fire(
                    'Success!',
                    'Student has been saved',
                    'success'
                )
            })

        }
    }

    // Fungsi untuk memanggil data kedalam form
    handleUpdate = (datas) => {
        this.setState({
            isUpdate: true
        })
        axios.get(`http://localhost:8000/api/student/${datas}`).then(res => {
            this.setState({
                formStudent: res.data.data
            })
        })
    }

    // Action Button
    action = (cell, row, rowIndex, formatExtraData) => {
        return (
            <div class="d-flex order-actions">
                <a data-tip data-for='edits' href="#" class="" onClick={() => {
                    this.openModal()
                    this.handleUpdate(row.id)
                }}><i class="bx bxs-edit"></i></a>
                <a data-tip data-for='ktp' href={"http://localhost:8000/kartupelajar/" + row.id} target="_blank" rel="noreferrer noopener" class="ms-3"><i class="bx bxs-credit-card-front"></i></a>
                <a data-tip data-for='deletes' href="#" class="ms-3" onClick={() => {
                    this.handleRemove(row.id)
                }}><i class="bx bxs-trash"></i></a>
                <ReactTooltip key={row.id} id='edits'>
                    <span>Edit Student</span>
                </ReactTooltip>
                <ReactTooltip key={row.id} id='ktp'>
                    <span>Get Student Card</span>
                </ReactTooltip>
                <ReactTooltip key={row.id} id='deletes'>
                    <span>Delete Student</span>
                </ReactTooltip>
            </div>
        )
    }

    // Fungsi untuk mengahapus data
    handleRemove = (id) => {
        swalWithBootstrapButtons.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'No, cancel!',
            reverseButtons: true
        }).then((result) => {
            if (result.isConfirmed) {
                axios({
                    method: "delete",
                    url: `http://localhost:8000/api/student/${id}`
                }).then((res) => {
                    this.getStudentApi();
                    swalWithBootstrapButtons.fire(
                        'Deleted!',
                        'Student has been deleted.',
                        'success'
                    )
                })
            } else if (
                result.dismiss === Swal.DismissReason.cancel
            ) {
            }
        })
    }

    // Fungsi untuk memanggil data
    getStudentApi = () => {
        API.getStudent().then(result => {
            this.setState({
                data: result
            })
        })
    }

    // Fungsi yang di render ketika pertama kali load
    componentDidMount() {
        this.getStudentApi();
    }


    render() {
        return <div>
            <div class="card">
                <div class="card-body">
                    <div id="invoice">
                        <div class="toolbar hidden-print">
                            <div class="text-end">
                                <button type="button" class="btn btn-dark"><i class="fa fa-print"></i> Print</button>
                                <button type="button" class="btn btn-danger"><i class="fa fa-file-pdf-o"></i> Export as PDF</button>
                            </div>
                            <hr />
                        </div>
                        <div class="invoice overflow-auto">
                            <div style={{
                                minWidth: '600px'
                            }}>
                                <header>
                                    <div class="row">
                                        <div class="col">
                                            <a href="javascript:;">
                                                <img src="assets/images/logo-icon.png" width="80" alt="" />
                                            </a>
                                        </div>
                                        <div class="col company-details">
                                            <h2 class="name">
                                                <a target="_blank" href="javascript:;">
                                                    Arboshiki
                                                </a>
                                            </h2>
                                            <div>455 Foggy Heights, AZ 85004, US</div>
                                            <div>(123) 456-789</div>
                                            <div>company@example.com</div>
                                        </div>
                                    </div>
                                </header>
                                <main>
                                    <div class="row contacts">
                                        <div class="col invoice-to">
                                            <div class="text-gray-light">INVOICE TO:</div>
                                            <h2 class="to">John Doe</h2>
                                            <div class="address">796 Silver Harbour, TX 79273, US</div>
                                            <div class="email"><a href="mailto:john@example.com">john@example.com</a>
                                            </div>
                                        </div>
                                        <div class="col invoice-details">
                                            <h1 class="invoice-id">INVOICE 3-2-1</h1>
                                            <div class="date">Date of Invoice: 01/10/2018</div>
                                            <div class="date">Due Date: 30/10/2018</div>
                                        </div>
                                    </div>
                                    <table>
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th class="text-left">DESCRIPTION</th>
                                                <th class="text-right">HOUR PRICE</th>
                                                <th class="text-right">HOURS</th>
                                                <th class="text-right">TOTAL</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td class="no">04</td>
                                                <td class="text-left">
                                                    <h3>
                                                        <a target="_blank" href="javascript:;">
                                                            Youtube channel
                                                        </a>
                                                    </h3>
                                                    <a target="_blank" href="javascript:;">
                                                        Useful videos
                                                    </a> to improve your Javascript skills. Subscribe and stay tuned :)</td>
                                                <td class="unit">$0.00</td>
                                                <td class="qty">100</td>
                                                <td class="total">$0.00</td>
                                            </tr>
                                            <tr>
                                                <td class="no">01</td>
                                                <td class="text-left">
                                                    <h3>Website Design</h3>Creating a recognizable design solution based on the company's existing visual identity</td>
                                                <td class="unit">$40.00</td>
                                                <td class="qty">30</td>
                                                <td class="total">$1,200.00</td>
                                            </tr>
                                            <tr>
                                                <td class="no">02</td>
                                                <td class="text-left">
                                                    <h3>Website Development</h3>Developing a Content Management System-based Website</td>
                                                <td class="unit">$40.00</td>
                                                <td class="qty">80</td>
                                                <td class="total">$3,200.00</td>
                                            </tr>
                                            <tr>
                                                <td class="no">03</td>
                                                <td class="text-left">
                                                    <h3>Search Engines Optimization</h3>Optimize the site for search engines (SEO)</td>
                                                <td class="unit">$40.00</td>
                                                <td class="qty">20</td>
                                                <td class="total">$800.00</td>
                                            </tr>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <td colspan="2"></td>
                                                <td colspan="2">SUBTOTAL</td>
                                                <td>$5,200.00</td>
                                            </tr>
                                            <tr>
                                                <td colspan="2"></td>
                                                <td colspan="2">TAX 25%</td>
                                                <td>$1,300.00</td>
                                            </tr>
                                            <tr>
                                                <td colspan="2"></td>
                                                <td colspan="2">GRAND TOTAL</td>
                                                <td>$6,500.00</td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                    <div class="thanks">Thank you!</div>
                                    <div class="notices">
                                        <div>NOTICE:</div>
                                        <div class="notice">A finance charge of 1.5% will be made on unpaid balances after 30 days.</div>
                                    </div>
                                </main>
                                <footer>Invoice was created on a computer and is valid without the signature and seal.</footer>
                            </div>
                            <div></div>
                        </div>
                    </div>
                </div>
            </div>
        </div >
    }
}

export default InvoiceComponent;